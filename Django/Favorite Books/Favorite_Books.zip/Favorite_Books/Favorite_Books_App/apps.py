from django.apps import AppConfig


class FavoriteBooksAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Favorite_Books_App'
